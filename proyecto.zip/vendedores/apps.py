from django.apps import AppConfig


class VendedoresConfig(AppConfig):
    name = 'vendedores'
