opciones_cuartos = {
    '1': 1,
    '2': 2,
    '3': 3,
    '4': 4,
    '5': 5,
    '6': 6,
    '7': 7,
}

opciones_precios = {
    '100000': 'Q100,000',
    '200000': 'Q200,000',
    '300000': 'Q300,000',
    '500000': 'Q500,000',
    '750000': 'Q750,000',
    '1000000': 'Q1M+',
}

opciones_depart = {
    'Alta Verapaz': 'Alta Verapaz',
    'Baja Verapaz': 'Baja Verapaz',
    'Chimaltenango': 'Chimaltenango',
    'Chiquimula': 'Chiquimula',
    'El Progreso': 'El Progreso',
    'Escuintla': 'Escuintla',
    'Guatemala': 'Guatemala',
    'Huehuetenango': 'Huehuetenango',
    'Izabal': 'Izabal',
    'Jalapa': 'Jalapa',
    'Jutiapa': 'Jutiapa',
    'Petén': 'Petén',
    'Quetzaltenango': 'Quetzaltenango',
    'Retalhuleu': 'Retalhuleu',
    'Sacatepéquez': 'Sacatepéquez',
    'San Marcos': 'San Marcos',
    'Sololá': 'Sololá',
    'Suchitepéquez': 'Suchitepéquez',
    'Totonicapán': 'Totonicapán',
}