from django.apps import AppConfig


class ListadosConfig(AppConfig):
    name = 'listados'
